module.exports = {
  preset: 'ts-jest',
  testEnvironment: 'node',
  roots: ['./src/__tests__'],
  moduleFileExtensions: ['ts', 'js', 'json', 'node'],
  transform: {
    "^.+\\.tsx?$": ["ts-jest", {
      tsconfig: 'tsconfig.jest.json'
    }]
  }
};
