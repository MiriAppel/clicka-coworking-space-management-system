import request from 'supertest';
import app from '../app';

describe('Security', () => {
    it('blocks access without token', async () => {
        const res = await request(app).get('/api/users/me');
        expect(res.status).toBe(401);
    });

    it('blocks unauthorized role from admin route', async () => {
        // מוקאינג של טוקן של משתמש רגיל
        const res = await request(app)
            .get('/api/admin/dashboard')
            .set('Authorization', 'Bearer usertoken');
        expect(res.status).toBe(403);
    });

    it('rejects invalid input', async () => {
        const res = await request(app)
            .post('/api/users')
            .send({ email: 'notanemail', name: '', role: 'MANAGER' });
        expect(res.status).toBe(400);
    });

    it('rejects expired token', async () => {
        const res = await request(app)
            .get('/api/users/me')
            .set('Authorization', 'Bearer expiredtoken');
        expect(res.status).toBe(401);
    });
});