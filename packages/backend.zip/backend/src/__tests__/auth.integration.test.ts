// import request from 'supertest';
// import app from '../app';

// describe('Google OAuth Authentication', () => {
//     it('redirects to Google OAuth on login', async () => {
//         const res = await request(app).get('/auth/google');
//         expect(res.status).toBe(302);
//         expect(res.headers.location).toContain('accounts.google.com');
//     });

//     it('returns error for invalid callback', async () => {
//         const res = await request(app).get('/auth/google/callback?error=access_denied');
//         expect(res.status).toBe(400);
//         expect(res.body.error).toBeDefined();
//     });

//     it('sets session and role after successful login', async () => {
//         // כאן יש לממש מוקאינג ל־Google, דוגמה:
//         const res = await request(app).get('/auth/google/callback?code=fakecode');
//         expect(res.status).toBe(200);
//         expect(res.body.user).toBeDefined();
//         expect(['MANAGER', 'ADMIN_ASSISTANT', 'SYSTEM_ADMIN']).toContain(res.body.user.role);
//     });

//     it('expires session after 8 hours', async () => {
//         // מוקאינג של session שפג תוקפו
//         const res = await request(app).get('/auth/session').set('Authorization', 'Bearer expiredtoken');
//         expect(res.status).toBe(401);
//         expect(res.body.error).toBe('Session expired');
//     });
// });


jest.mock('../services/authService', () => ({
    loginWithGoogle: jest.fn(() => Promise.resolve({
        user: { id: '1', email: 'user@test.com', role: 'MANAGER' },
        token: 'mocked-token'
    })),
    verifySession: jest.fn(() => Promise.resolve(true))
}));

import request from 'supertest';
import app from '../app';

describe('Google OAuth Authentication', () => {
    it('redirects to Google OAuth on login', async () => {
        const res = await request(app).get('/auth/google');
        expect(res.status).toBe(302);
        expect(res.headers.location).toContain('accounts.google.com');
    });

    it('sets session and role after successful login', async () => {
        const res = await request(app).get('/auth/google/callback?code=fakecode');
        expect(res.status).toBe(200);
        expect(res.body.user).toBeDefined();
        expect(res.body.token).toBe('mocked-token');
        expect(res.body.user.role).toBe('MANAGER');
    });
});