// import request from 'supertest';
// import app from '../app';
// import path from 'path';

// describe('Google Drive Integration', () => {
//     it('uploads file to drive', async () => {
//         const res = await request(app)
//             .post('/api/drive/upload')
//             .attach('file', path.join(__dirname, 'testfile.pdf'))
//             .field('category', 'contract');
//         expect(res.status).toBe(201);
//         expect(res.body.fileId).toBeDefined();
//     });

//     it('prevents upload of large file', async () => {
//         // מוקאינג של קובץ גדול
//         const res = await request(app)
//             .post('/api/drive/upload')
//             .attach('file', path.join(__dirname, 'largefile.pdf'))
//             .field('category', 'contract');
//         expect(res.status).toBe(413); // Payload Too Large
//     });

//     it('handles duplicate filename', async () => {
//         // מוקאינג של קובץ עם שם קיים
//         const res = await request(app)
//             .post('/api/drive/upload')
//             .attach('file', path.join(__dirname, 'testfile.pdf'))
//             .field('category', 'contract');
//         expect([200, 409]).toContain(res.status); // 409 = Conflict
//     });
// });


jest.mock('../services/driveService', () => ({
    uploadFile: jest.fn(() => Promise.resolve({ fileId: 'mocked-file-id' })),
    createFolder: jest.fn(() => Promise.resolve('mocked-folder-id')),
    shareFile: jest.fn(() => Promise.resolve()),
    deleteFile: jest.fn(() => Promise.resolve())
}));

import request from 'supertest';
import app from '../app';

describe('Google Drive Integration', () => {
    it('uploads file to drive', async () => {
        const res = await request(app)
            .post('/api/drive/upload')
            .field('category', 'contract');
        expect(res.status).toBe(201);
        expect(res.body.fileId).toBe('mocked-file-id');
    });

    it('creates folder', async () => {
        const res = await request(app)
            .post('/api/drive/folder')
            .send({ name: 'New Folder' });
        expect(res.status).toBe(201);
        expect(res.body.folderId).toBe('mocked-folder-id');
    });
});