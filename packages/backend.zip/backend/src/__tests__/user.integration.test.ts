import request from 'supertest';
import app from '../app';

describe('User Management', () => {
    it('creates user with role', async () => {
        const res = await request(app)
            .post('/api/users')
            .send({ email: 'test@test.com', name: 'Test', role: 'MANAGER' });
        expect(res.status).toBe(201);
        expect(res.body.user.role).toBe('MANAGER');
    });

    it('prevents unauthorized role assignment', async () => {
        const res = await request(app)
            .post('/api/users')
            .send({ email: 'test2@test.com', name: 'Test2', role: 'SYSTEM_ADMIN' });
        expect(res.status).toBe(403);
    });

    it('deactivates user', async () => {
        const res = await request(app)
            .patch('/api/users/123/deactivate');
        expect(res.status).toBe(200);
        expect(res.body.user.isActive).toBe(false);
    });

    it('prevents login for deactivated user', async () => {
        const res = await request(app)
            .post('/auth/login')
            .send({ email: 'deactivated@test.com', password: '123456' });
        expect(res.status).toBe(403);
        expect(res.body.error).toBe('User is deactivated');
    });
});