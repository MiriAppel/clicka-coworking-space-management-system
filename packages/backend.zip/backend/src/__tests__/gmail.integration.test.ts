// import request from 'supertest';
// import app from '../app';

// describe('Email Notification', () => {
//     it('sends email with template', async () => {
//         const res = await request(app)
//             .post('/api/email/send')
//             .send({
//                 to: ['user@test.com'],
//                 templateId: 'welcome',
//                 variables: { name: 'User' }
//             });
//         expect(res.status).toBe(200);
//         expect(res.body.status).toBe('sent');
//     });

//     it('rejects invalid email address', async () => {
//         const res = await request(app)
//             .post('/api/email/send')
//             .send({
//                 to: ['notanemail'],
//                 templateId: 'welcome',
//                 variables: { name: 'User' }
//             });
//         expect(res.status).toBe(400);
//         expect(res.body.error).toBeDefined();
//     });

//     it('prevents sending large attachment', async () => {
//         // מוקאינג של קובץ גדול
//         const res = await request(app)
//             .post('/api/email/send')
//             .send({
//                 to: ['user@test.com'],
//                 templateId: 'welcome',
//                 variables: { name: 'User' },
//                 attachments: [{ name: 'bigfile.pdf', size: 30000000 }]
//             });
//         expect(res.status).toBe(413);
//     });
// });


jest.mock('../services/gmailService', () => ({
    sendEmail: jest.fn(() => Promise.resolve({ status: 'sent', messageId: 'mocked-id' }))
}));

import request from 'supertest';
import app from '../app';

describe('Email Notification', () => {
    it('sends email with template', async () => {
        const res = await request(app)
            .post('/api/email/send')
            .send({
                to: ['user@test.com'],
                templateId: 'welcome',
                variables: { name: 'User' }
            });
        expect(res.status).toBe(200);
        expect(res.body.status).toBe('sent');
        expect(res.body.messageId).toBe('mocked-id');
    });
});