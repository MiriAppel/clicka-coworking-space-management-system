// import request from 'supertest';
// import app from '../app';

// describe('Google Calendar Integration', () => {
//     it('creates calendar event', async () => {
//         const res = await request(app)
//             .post('/api/calendar/events')
//             .send({
//                 summary: 'פגישה',
//                 start: '2025-07-20T10:00:00Z',
//                 end: '2025-07-20T11:00:00Z',
//                 attendees: ['user@test.com']
//             });
//         expect(res.status).toBe(201);
//         expect(res.body.eventId).toBeDefined();
//     });

//     it('rejects event with invalid time zone', async () => {
//         const res = await request(app)
//             .post('/api/calendar/events')
//             .send({
//                 summary: 'פגישה',
//                 start: 'invalid-date',
//                 end: 'invalid-date',
//                 attendees: ['user@test.com']
//             });
//         expect(res.status).toBe(400);
//         expect(res.body.error).toBeDefined();
//     });

//     it('checks room availability', async () => {
//         const res = await request(app)
//             .get('/api/calendar/availability?room=1&start=2025-07-20T10:00:00Z&end=2025-07-20T11:00:00Z');
//         expect(res.status).toBe(200);
//         expect(typeof res.body.available).toBe('boolean');
//     });
// });


jest.mock('../services/calendarService', () => ({
    createEvent: jest.fn(() => Promise.resolve({ eventId: 'mocked-event-id' })),
    checkAvailability: jest.fn(() => Promise.resolve(true))
}));

import request from 'supertest';
import app from '../app';

describe('Google Calendar Integration', () => {
    it('creates calendar event', async () => {
        const res = await request(app)
            .post('/api/calendar/events')
            .send({
                summary: 'פגישה',
                start: '2025-07-20T10:00:00Z',
                end: '2025-07-20T11:00:00Z',
                attendees: ['user@test.com']
            });
        expect(res.status).toBe(201);
        expect(res.body.eventId).toBe('mocked-event-id');
    });

    it('checks room availability', async () => {
        const res = await request(app)
            .get('/api/calendar/availability?room=1&start=2025-07-20T10:00:00Z&end=2025-07-20T11:00:00Z');
        expect(res.status).toBe(200);
        expect(res.body.available).toBe(true);
    });
});