// controllers/translation.controller.ts
// import { Request, Response } from 'express';
// import { translationService } from '../services/translation.service';
// import type { ID } from 'shared-types';

// export const translationController = {



  // create: async (req: Request, res: Response) => {
  //   try {
  //     const newItem = await translationService.createWithTranslations(req.body);
  //     return res.status(201).json(newItem);
  //   } catch (error: any) {
  //     res.status(400).json({ error: error.message });
  //   }
  // },


//       const result = await translationService.createWithTranslations({ key, text, lang });
//       res.status(201).json(result);
//     }
//     catch (error: any) {
//       res.status(500).json({ error: error.message });
//     }
//   }
// }
