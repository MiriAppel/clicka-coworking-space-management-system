//מחזיר את הזמינות הנוכחית לכל סוגי חללי העבודה לפי תנאי שאילתה
export async function checkAvailabilityRoom(id: any) { 
}
//מחזיר תחזיות תפוסה
export async function getAvailabilityForecast(id: any) { 
}
 //מאפשר למערכות אחרות לבדוק זמינות עבור נכסים מרובים
export async function getBulkAvailability(id: any) { 
}
//קבלת התראות זמינות נמוכה רישום לקבלת התראות כאשר זמינות יורדת מתחת לסף מסוים
export async function subscribeToLowAvailable(id: any) { 
}
//מחזיר תצוגת לוח שנה של זמינות עבור חדר ישיבות ספציפי
export async function getAvailabilityCalendar(id: any) { 
}
//חישוב זמינות בהתחשב בתחזוקה והזמנות קיימות
export async function calculateAvailabilityWithConstraints(id: any) { 
}
//אימות שאילתות זמינות
export async function validateAvailabilityQuweies(id: any) { 
}
